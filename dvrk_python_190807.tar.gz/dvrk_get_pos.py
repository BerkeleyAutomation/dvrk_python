import threading
import rospy
import geometry_msgs.msg
import sensor_msgs.msg
import numpy as np
from tf_conversions import posemath

def rad_to_deg(rad):
	return np.array(rad)*180./np.pi

def deg_to_rad(deg):
    return np.array(deg)*np.pi/180.

MILLION = 10**6

class PositionSubscriber(threading.Thread):
    def __init__(self,arm_name,node_name,interval_ms):

        # ========SUBSCRIBERS========#
        # position subscriber
        self.arm_name = arm_name
        self.node_name = node_name
        rospy.init_node(node_name, anonymous=True)
        rospy.Subscriber("/dvrk/"+arm_name+"/position_cartesian_current", geometry_msgs.msg.PoseStamped,
                         self.position_callback, queue_size=1)
        rospy.Subscriber("/dvrk/"+arm_name+"/state_jaw_current", sensor_msgs.msg.JointState, self.jaw_callback, queue_size=1)
        threading.Thread.__init__(self)
        self.interval_ms = interval_ms
        self.cnt = 0.0
        self.pos_curr = [0.0, 0.0, 0.0]
        self.rot_curr = [0.0, 0.0, 0.0]
        self.jaw_curr = [0.0]
        self.unit = "rad"
        self.rate = rospy.Rate(1000.0/interval_ms)

    def start(self):
        self.stop_flag = False
        self.thread = threading.Thread(target=self.run, args=(lambda: self.stop_flag,))
        self.thread.daemon = True
        self.thread.start()

    def stop(self):
        self.stop_flag = True

    def position_callback(self, msg):
        if rospy.is_shutdown():
            return
        # convert the pose into a kdl frame
        frame_curr = posemath.fromMsg(msg.pose)
        self.pos_curr = [frame_curr.p[0], frame_curr.p[1], frame_curr.p[2]]       # current position in (mm)
        rz,ry,rx = frame_curr.M.GetEulerZYX()

        if self.unit == "deg":
            self.rot_curr =rad_to_deg((np.array([np.pi/2, 0, np.pi]) - [rz,ry,rx]))
        elif self.unit == "rad":
            self.rot_curr = np.array([np.pi/2, 0, np.pi]) - [rz, ry, rx]

    def jaw_callback(self, msg):
        if rospy.is_shutdown():
            return
        if self.unit == "deg":
            self.jaw_curr = rad_to_deg(msg.position)
        elif self.unit == "rad":
            self.jaw_curr = msg.position

    def run(self, stop):
        while not rospy.is_shutdown():
            # To do
            self.cnt += 1000.0/MILLION*self.interval_ms
            self.rate.sleep()
            if stop():
                break

    def rot_unit(self, unit):
        self.unit = unit

if __name__ == "__main__":
    ps = PositionSubscriber(100)
    ps.start()