import threading
import rospy
import geometry_msgs.msg
import sensor_msgs.msg
import PyKDL
import numpy as np
from tf_conversions import posemath

def rad_to_deg(rad):
	return np.array(rad)*180./np.pi

def deg_to_rad(deg):
    return np.array(deg)*np.pi/180.

MILLION = 10**6

class PositionPublisher(threading.Thread):
    def __init__(self,arm_name,node_name,interval_ms):

        #========PUBLISHERS========#
        # position publishers
        self.arm_name = arm_name
        self.node_name = node_name
        self.pub1 = rospy.Publisher("/dvrk/"+arm_name+"/set_position_goal_cartesian", geometry_msgs.msg.Pose, queue_size=1)
        self.pub2 = rospy.Publisher("/dvrk/"+arm_name+"/set_position_goal_jaw", sensor_msgs.msg.JointState, queue_size=1)
        rospy.init_node(self.node_name, anonymous=True)
        threading.Thread.__init__(self)
        self.interval_ms = interval_ms
        self.cnt = 0.0
        self.pos_des = [0.0, 0.0, 0.0]
        self.rot_des = [0.0, 0.0, 0.0]
        self.jaw_des = [0.0, 0.0, 0.0]
        self.rate = rospy.Rate(1000.0 / interval_ms)

    def move(self,pos,rot,jaw,unit):
        """
        Moves the PSM to the pose specified by (pos, rot).
        rot vector specifies ZYX euler angles
        """
        self.pos_des = pos
        if unit == "rad":
            self.rot_des = rot
            self.jaw_des = jaw
        elif unit == "deg":
            self.rot_des = deg_to_rad(rot)
            self.jaw_des = deg_to_rad(jaw)

    def start(self):
        self.stop_flag = False
        self.thread = threading.Thread(target=self.run, args=(lambda: self.stop_flag,))
        self.thread.daemon = True
        self.thread.start()

    def stop(self):
        self.stop_flag = True

    def run(self, stop):
        while not rospy.is_shutdown():
            # To do
            px, py, pz = self.pos_des
            rz, ry, rx = np.array([np.pi/2, 0, -np.pi]) - np.array(self.rot_des)
            pos_ = PyKDL.Vector(px, py, pz)
            rot_ = PyKDL.Rotation.EulerZYX(rz, ry, rx)
            frame_des = PyKDL.Frame(rot_, pos_)
            msg_pose = posemath.toMsg(frame_des)
            msg_jaw = sensor_msgs.msg.JointState()
            msg_jaw.position = self.jaw_des
            self.pub1.publish(msg_pose)
            self.pub2.publish(msg_jaw)
            self.cnt += 1000.0/MILLION*self.interval_ms
            self.rate.sleep()
            if stop():
                break

if __name__ == "__main__":
    p = PositionPublisher("PSM1","position_publisher_node",10)
    while True:
        pos = [0.0, 0.0, -0.07]  # Position (m)
        rot = [0, 0, 0]  # Euler angle ZYX (rad) (similar to roll-pitch-yaw)
        jaw = [0]
        p.move(pos, rot, jaw, "rad")