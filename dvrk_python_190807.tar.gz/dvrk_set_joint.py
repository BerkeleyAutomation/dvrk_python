import threading
import rospy
import sensor_msgs.msg
import numpy as np

def rad_to_deg(rad):
	return np.array(rad)*180./np.pi

def deg_to_rad(deg):
    return np.array(deg)*np.pi/180.

MILLION = 10**6

class JointPublisher(threading.Thread):
    def __init__(self,arm_name,node_name,interval_ms):

        #========PUBLISHERS========#
        # joint publishers
        self.arm_name = arm_name
        self.node_name = node_name
        self.pub1 = rospy.Publisher("/dvrk/"+arm_name+"/set_position_goal_joint", sensor_msgs.msg.JointState, queue_size=1)
        self.pub2 = rospy.Publisher("/dvrk/"+arm_name+"/set_position_goal_jaw", sensor_msgs.msg.JointState, queue_size=1)
        rospy.init_node(self.node_name, anonymous=True)
        threading.Thread.__init__(self)
        self.interval_ms = interval_ms
        self.cnt = 0.0
        self.joint_des = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        self.rate = rospy.Rate(1000.0 / interval_ms)

    def move(self,joint_des,unit):
        """
        Set the joint angle of the PSM specified by joint_des
        rot vector specifies RPY euler angles
        """
        if unit == "rad":
            self.joint_des = joint_des
        elif unit == "deg":
            self.joint_des = deg_to_rad(joint_des)
            self.joint_des[2] = joint_des[2]

    def start(self):
        self.stop_flag = False
        self.thread = threading.Thread(target=self.run, args=(lambda: self.stop_flag,))
        self.thread.daemon = True
        self.thread.start()

    def stop(self):
        self.stop_flag = True

    def run(self, stop):
        while not rospy.is_shutdown():
            # To do
            msg_joint = sensor_msgs.msg.JointState()
            msg_joint.position = self.joint_des
            msg_jaw = sensor_msgs.msg.JointState()
            msg_jaw.position = [self.joint_des[6]]
            self.pub1.publish(msg_joint)
            self.pub2.publish(msg_jaw)
            self.cnt += 1000.0/MILLION*self.interval_ms
            self.rate.sleep()
            if stop():
                break

if __name__ == "__main__":
    p = JointPublisher("PSM1", "joint_publisher_node", 10)
    p.start()
    while not rospy.is_shutdown():
        try:
            j_des = [0, 0, 0.08, 0, 0, 0, 0]
            p.move(j_des, "rad")
        except rospy.ROSInterruptException:
            pass