import threading
import rospy
import sensor_msgs.msg
import numpy as np

def rad_to_deg(rad):
	return np.array(rad)*180./np.pi

def deg_to_rad(deg):
    return np.array(deg)*np.pi/180.

MILLION = 10**6

class JointSubscriber(threading.Thread):
    def __init__(self, arm_name, node_name, interval_ms):

        #========SUBSCRIBERS========#
        # joint subscriber
        self.arm_name = arm_name
        self.node_name = node_name
        rospy.init_node(node_name, anonymous=True)
        rospy.Subscriber("/dvrk/"+arm_name+"/io/joint_position", sensor_msgs.msg.JointState, self.joint_callback,
                         queue_size=1)
        threading.Thread.__init__(self)
        self.interval_ms = interval_ms
        self.cnt = 0.0
        self.joint_curr = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        self.unit = "rad"
        self.rate = rospy.Rate(1000.0 / interval_ms)

    def start(self):
        self.stop_flag = False
        self.thread = threading.Thread(target=self.run, args=(lambda: self.stop_flag,))
        self.thread.daemon = True
        self.thread.start()

    def stop(self):
        self.stop_flag = True

    def joint_callback(self, msg):
        if rospy.is_shutdown():
            return
        if self.unit == "deg":
            self.joint_curr = rad_to_deg(msg.position)
            self.joint_curr[2] = msg.position[2]
        elif self.unit == "rad":
            self.joint_curr = msg.position      # unit: (rad), (m)

    def run(self, stop):
        while not rospy.is_shutdown():
            # To do
            self.cnt += 1000.0/MILLION*self.interval_ms
            self.rate.sleep()
            if stop():
                break

    def rot_unit(self, unit):
        self.unit = unit

if __name__ == "__main__":
    ps = JointSubscriber("PSM1", "joint_subscriber_node", 100)